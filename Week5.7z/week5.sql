use coffeeshop;
drop procedure if exists coffeeshop()
delimiter //
create procedure coffeeshop ()
begin
declare sql_error int default false;
declare continue handler for sqlexception set sql_error = true;
start transaction;

insert into orders values (null,"25/7/2566", "60", 1);
set @last_id = last_insert_id();
insert into order_details values(null, 1 , 1, @last_id);

insert into orders values(null,"25/7/2566", "60", 1);
set @last_id = last_insert_id();
insert into order_details values(null,2 , 2, @last_id); 

insert into orders values(null,"25/7/2566", "60", 1);
set @last_id = last_insert_id();
insert into order_details values(null,1 , 3, @last_id);
 
if sql_error = false then commit;
select 'the transaction was commited.';
else
rollback;
select ' the transaction was rolled back.';
end if;
end//
delimiter ;

call coffeeshop();

select members.Name, `Level of sweet`, count(Quantity) from members join orders using (member_ID)
join order_details using (Orders_ID) join coffee using (Coffee_ID)
group by members.Name,`Level of sweet`;


