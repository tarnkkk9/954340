drop trigger if exists credit;
delimiter //
create trigger credit
after insert on registration_details for each row
begin
declare total float;
select sum(Credit) into total from registration_details
join section using (SectionID)
join course using (CourseID)
where RegistrationID = new.RegistrationID;

update registration set Credittotal = total where RegistrationID = new.RegistrationID;
end//
delimiter ;

show triggers;

insert into registration_details value (null, 1, 1);
insert into registration_details value (null, 2, 2);
insert into registration_details value (null, 2, 3), (null, 3, 3);

select * from registration;