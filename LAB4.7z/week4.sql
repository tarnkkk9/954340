use restaurant;
drop procedure if exists week4;
delimiter //
create procedure week4()
begin
insert into menus values (null, "pizza", 199), (null, "ramen", 169);
insert into orders values (null, 1, 199), (null, 2, 169);
insert into order_details values (null, 1, 1, 3), (null, 2, 2, 4);
end //
delimiter ;
call week4();


create view Report as
select Order_detail_ID, menu,quantity, price, sum(quantity*price) as total from orders join order_details using (Order_ID) join menus using (Menu_id)
group by Order_detail_ID;
select * from Report;

